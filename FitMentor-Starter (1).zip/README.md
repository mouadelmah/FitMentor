# FitMentor — Starter Site

**Catégorie:** Coaching / Fitness  
**Plateforme recommandée:** GitHub Pages (compatible Netlify / Vercel)  
**Fichiers inclus:**
- index.html
- logo.png

## Pitch court (à utiliser pour tes annonces)
Landing page professionnelle pour un coach sportif : programmes, témoignages, réservation. Idéal comme "starter site" à revendre.

## Description longue (exemple pour Flippa / Dan)
FitMentor est une landing page moderne et responsive conçue pour coachs personnels et studios de fitness. Elle inclut une section hero, offres, fonctionnalités, témoignages simples et un formulaire de contact (email affiché). Le design est épuré et prêt à être personnalisé.

## Comment déployer (GitHub Pages)
1. Crée un nouveau repo sur GitHub (ex: `fitmentor`).
2. Ajoute les fichiers `index.html` et `logo.png` dans la racine du repo.
3. Dans GitHub → Settings → Pages → Source → sélectionne `main` branch et `/ (root)` puis Save.
4. Attends quelques minutes, puis ton site sera disponible sous `https://<ton-username>.github.io/fitmentor/`.

## Comment déployer (Netlify)
1. Crée un repo GitHub et pousse les fichiers.
2. Connecte ton compte Netlify → New site from Git → choisis le repo → Deploy.
3. Netlify te fournira une URL du type `https://fitmentor-xxxxx.netlify.app`.

## Modifier le contenu
- Pour changer le logo : remplace `logo.png` par ton image (même nom).
- Pour changer l'email de contact : édite la ligne dans `index.html` (section #contact).

## Conseils de vente
- Prix suggéré: 20€–80€ selon audience et qualité de listing.
- Ajoute un screenshot en miniature et le lien de démo.
- Fourni le README avec la vente pour que l'acheteur déploie facilement.

---
Bonne vente !
